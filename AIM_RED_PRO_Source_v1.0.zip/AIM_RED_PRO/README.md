# AIM RED PRO

Ứng dụng Android luyện tập ngắm mục tiêu độc lập.

## Tính năng
- Màn hình nhập key offline: `Hoaidz`
- Aim Trainer chạm mục tiêu trong 30 giây
- Mô phỏng crosshair trong ứng dụng
- Thanh luyện cảm giác độ nhạy (không thay đổi cài đặt game)
- Lưu kỷ lục trên thiết bị

## Giới hạn quan trọng
- Đây là ứng dụng luyện tập độc lập, không đọc/ghi bộ nhớ trò chơi, không tự động ngắm, không điều khiển Free Fire.
- Key `Hoaidz` được đặt trong mã nguồn để làm khóa mở ứng dụng mẫu; vì vậy không phải cơ chế bảo mật mạnh và có thể bị tìm thấy nếu ai xem mã nguồn/APK.
- APK chưa được ký phát hành bằng khóa riêng. GitHub Actions tạo APK debug để thử nghiệm, không phải bản phát hành chính thức.
- Cần chạy GitHub Actions để tạo APK. Không có APK cài đặt sẵn trong repository.

## Build tự động trên GitHub
Sau khi tải toàn bộ nội dung dự án lên repository nhánh `main`:
1. Mở tab **Actions**.
2. Chọn **Build AIM RED PRO APK**.
3. Nhấn **Run workflow** nếu workflow chưa tự chạy.
4. Chờ trạng thái màu xanh hoàn tất.
5. Mở lần chạy đó và tải artifact `AIM-RED-PRO-debug`.

## Build thủ công
Cần Android SDK, JDK 17 và Gradle 8.9:
`gradle assembleDebug`
