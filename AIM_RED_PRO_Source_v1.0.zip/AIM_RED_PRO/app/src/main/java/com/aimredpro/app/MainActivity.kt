package com.aimredpro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.SeekBar
import android.widget.Toast
import android.os.Handler
import android.os.Looper
import kotlin.random.Random

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 16)
    private val red = Color.rgb(255, 45, 65)
    private val white = Color.WHITE
    private val prefs by lazy { getSharedPreferences("aim_red_pro", MODE_PRIVATE) }
    private var bestScore = 0
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bestScore = prefs.getInt("best", 0)
        showKeyScreen()
    }

    private fun setupRoot() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 24)
            setBackgroundColor(bg)
        }
        setContentView(root)
    }

    private fun title(text: String, size: Float = 28f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(white)
            setBackgroundColor(red)
            textSize = 16f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun showKeyScreen() {
        setupRoot()
        root.addView(title("AIM RED PRO", 32f))
        root.addView(title("OFFLINE AIM TRAINER", 13f))
        val input = EditText(this).apply {
            hint = "Nhập key"
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            textSize = 18f
            gravity = Gravity.CENTER
            setSingleLine(true)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 60))
        root.addView(button("MỞ ỨNG DỤNG") {
            if (input.text.toString().trim() == "Hoaidz") {
                prefs.edit().putBoolean("unlocked", true).apply()
                showDashboard()
            } else {
                Toast.makeText(this, "Key không đúng. Hãy thử lại.", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-1, 56).apply { topMargin = 16 })
        root.addView(title("Công cụ luyện tập độc lập • Không can thiệp trò chơi", 12f))
    }

    private fun showDashboard() {
        setupRoot()
        root.addView(title("AIM RED PRO", 32f))
        root.addView(title("BẢNG ĐIỀU KHIỂN", 14f))
        root.addView(title("Kỷ lục luyện tập: $bestScore điểm", 16f))
        root.addView(button("BẮT ĐẦU LUYỆN AIM") { startTraining() },
            LinearLayout.LayoutParams(-1, 58).apply { topMargin = 16 })
        root.addView(button("MÔ PHỎNG CROSSHAIR") { showCrosshair() },
            LinearLayout.LayoutParams(-1, 58).apply { topMargin = 10 })
        root.addView(button("LUYỆN ĐỘ NHẠY") { showSensitivity() },
            LinearLayout.LayoutParams(-1, 58).apply { topMargin = 10 })
        root.addView(button("THOÁT VỀ MÀN HÌNH KEY") { showKeyScreen() },
            LinearLayout.LayoutParams(-1, 52).apply { topMargin = 24 })
    }

    private fun startTraining() {
        val game = AimGameView()
        setContentView(game)
        game.start()
    }

    private fun showCrosshair() {
        setupRoot()
        root.addView(title("CROSSHAIR SIMULATOR"))
        val preview = CrosshairView(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("QUAY LẠI") { showDashboard() },
            LinearLayout.LayoutParams(-1, 54))
    }

    private fun showSensitivity() {
        setupRoot()
        root.addView(title("LUYỆN ĐỘ NHẠY"))
        val value = title("Mức luyện tập: 50", 20f)
        root.addView(value)
        val seek = SeekBar(this).apply {
            max = 100
            progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    value.text = "Mức luyện tập: $p"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(seek, LinearLayout.LayoutParams(-1, 60))
        root.addView(title("Đây là thanh mô phỏng để luyện cảm giác tay; không thay đổi cài đặt Free Fire.", 13f))
        root.addView(button("QUAY LẠI") { showDashboard() },
            LinearLayout.LayoutParams(-1, 54))
    }

    private inner class AimGameView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var x = 200f
        private var y = 300f
        private var score = 0
        private var seconds = 30
        private var running = false
        private val handler = Handler(Looper.getMainLooper())
        private val tick = object : Runnable {
            override fun run() {
                if (!running) return
                seconds--
                if (seconds <= 0) {
                    running = false
                    val previous = prefs.getInt("best", 0)
                    bestScore = maxOf(previous, score)
                    prefs.edit().putInt("best", bestScore).apply()
                    Toast.makeText(this@MainActivity, "Hết giờ! Bạn đạt $score điểm", Toast.LENGTH_LONG).show()
                    showDashboard()
                } else {
                    invalidate()
                    handler.postDelayed(this, 1000)
                }
            }
        }

        fun start() {
            score = 0
            seconds = 30
            running = true
            handler.postDelayed(tick, 1000)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(bg)
            paint.color = white
            paint.textSize = 42f
            canvas.drawText("AIM RED PRO", 32f, 70f, paint)
            paint.textSize = 24f
            canvas.drawText("Điểm: $score", 32f, 115f, paint)
            canvas.drawText("Thời gian: ${seconds}s", 32f, 150f, paint)
            paint.color = red
            canvas.drawCircle(x, y, 42f, paint)
            paint.color = white
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            canvas.drawCircle(x, y, 42f, paint)
            paint.style = Paint.Style.FILL
            paint.textSize = 17f
            canvas.drawText("Chạm vào mục tiêu • 30 giây", 32f, height - 40f, paint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN && running) {
                val dx = event.x - x
                val dy = event.y - y
                if (dx * dx + dy * dy <= 42f * 42f) {
                    score++
                    x = Random.nextFloat() * (width - 100).coerceAtLeast(1) + 50
                    y = Random.nextFloat() * (height - 240).coerceAtLeast(1) + 180
                    invalidate()
                }
                return true
            }
            return true
        }
    }

    private class CrosshairView(context: android.content.Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.RED
            strokeWidth = 5f
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(24, 24, 30))
            val cx = width / 2f
            val cy = height / 2f
            canvas.drawLine(cx - 38, cy, cx - 10, cy, p)
            canvas.drawLine(cx + 10, cy, cx + 38, cy, p)
            canvas.drawLine(cx, cy - 38, cx, cy - 10, p)
            canvas.drawLine(cx, cy + 10, cx, cy + 38, p)
            canvas.drawCircle(cx, cy, 4f, p)
        }
    }
}
